async function generateToolZip() {
    const toolName = document.getElementById('tool-name-input').value;
    let authorName = document.getElementById('tool-author-input').value;
    if (toolName === undefined || toolName === "") {
        return;
    }
    if (authorName === "") {
        authorName = "Unknown";
    }
    // Capitalize first letter and strip of whitespace
    const toolFuncName = toolName.charAt(0).toUpperCase() + toolName.slice(1).replace(/\s/g, '');

    const zip = new JSZip();
    const rootFolder = zip.folder(toolFuncName);
    
    const project = generateManifest(toolFuncName, authorName);
    rootFolder.file("project.mf.xml", project);

    const scriptsFolder = rootFolder.folder("scripts");
    scriptsFolder.file("Bootstrap.lua", STATIC_RESOURCES["Bootstrap.lua"]);
    const toolLua = generateToolLua(toolFuncName);
    scriptsFolder.file(`${toolFuncName}.lua`, toolLua);

    const resourcesFolder = rootFolder.folder("resources");
    const helpFolder = resourcesFolder.folder("help");
    helpFolder.file("en.html", generateHelpHtml(toolName));
    const langFolder = resourcesFolder.folder("lang");
    langFolder.file("en.json", generateLangJson(toolName, toolFuncName));

    jdenticon.update("#jdenticonCanvas", toolName);

    let canvas = document.getElementById('jdenticonCanvas');
    const imageBlob = await canvasToBlob(canvas);

    resourcesFolder.file(`${toolFuncName}.png`, imageBlob, {binary: true});
    
    zip.generateAsync({type:"blob"})
    .then(function(content) {
        saveAs(content, toolFuncName + ".zip");
    });
}

function canvasToBlob(canvas) {
    return new Promise((resolve, reject) => {
        canvas.toBlob(blob => {
            resolve(blob);
        }, "image/png");
    });
}
