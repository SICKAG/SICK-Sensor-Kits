function generateManifest(projectName, authorName) {
    return `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<manifest>
    <application name="${projectName}">
        <crown name="${projectName}">
            <desc></desc>
            <serves>
                <event name="ToolEvent">
                    <desc></desc>
                    <param name="arg" type="string" desc=""/>
                </event>
                <function name="command">
                    <desc></desc>
                    <param name="cmd" type="string" desc=""/>
                    <param name="arg" type="auto" multiplicity="?" desc=""/>
                    <return name="result" type="auto" multiplicity="?" desc=""/>
                </function>
                <function name="ui">
                    <desc></desc>
                    <param name="cmd" type="string" desc=""/>
                    <param name="arg" type="auto" desc=""/>
                    <return name="result" type="string" desc=""/>
                </function>
            </serves>
        </crown>
        <meta key="author">${authorName}</meta>
        <meta key="version">0.0.0</meta>
        <meta key="priority">low</meta>
        <meta key="read-protected">false</meta>
        <meta key="copy-protected">false</meta>
        <entry path="scripts" default="Bootstrap.lua"/>
    </application>
</manifest>
`;
}

function generateToolLua(toolFuncName) {
    return `local Tool = require("Nova.Tool")

local _${toolFuncName} = Tool.register{
  category="Analysis",
  parameters={},
  results={{name="Pass", type='bool'}}
}

function _${toolFuncName}:execute(input, output)

  local function setResults()
    output:add("Pass", true)
  end

  if input:parentFail() then
    return setResults()
  end

  setResults()
end
`
}

function generateHelpHtml(toolName) {
    return `<html>
  <head>
    <title>${toolName}</title>
    <style>
      a {
        color: #0084c2;
        text-decoration: none;
      }
  
      a:hover {
        text-decoration: underline;
      }
  
      body {
        margin-left: 38px;
        margin-top: 25px;
        padding: 0%;
        font-family: Tahoma, Geneva, sans-serif;
        font-size: 12px;
        line-height: 130%;
        color: #555;
      }
  
      .content {
        max-width: 700px;
      }
  
      h1 {
        font-size: 30px;
        line-height: 30px;
      }
  
      p {
        padding: 0;
        margin: 0 0 15px;
        line-height: 12px;
        font-size: 12px;
      }
  
      td {
        vertical-align: top;
      }
  
      .table-normal {
        display: table;
        border-spacing: 2px;
        border-color: grey;
        border: 1px solid #a7a9ac;
        border-collapse: collapse;
        width: 100%;
        font-size: 12px;
        margin-bottom: 1em
      }
  
      .table-nolines {
        display: table;
        border-spacing: 2px;
        border: 0;
        border-collapse: collapse;
        width: 100%;
        font-size: 12px;
        margin-bottom: 1em
      }
  
      .headline {
        color: #0084c2;
        font-weight: normal;
        margin-bottom: 10px;
      }
  
      .label {
        font-size: 13px;
        font-weight: bold;
        margin-bottom: 7px;
      }
  
      .table-normal,
      td {
        border: 1px solid #a7a9ac;
        padding: 4px;
        margin: 7px 0px 7px 0px;
      }
  
      .table-nolines td {
        border: 0px solid;
        padding: 4px;
        margin: 7px 0px 7px 0px;
      }
  
      .table-header {
        background-color: #b9bec2;
      }
  
      .emphasis {
        font-weight: bold;
        color: #444546;
      }
  
      .codeinline {
        font-family: "Courier New", Courier, monospace;
        color: #000000;
      }
  
      .enum-element,
      .step {
        margin: 3px 0 3px 0;
      }
  
      .step {
        padding-left: 10px;
        margin-top: 10px;
      }
  
      .step.result {
        list-style: none;
      }
  
      .step.result:before {
        counter-increment: none;
        display: block;
        content: "\\2714";
        /* Checkmark symbol */
  
        height: 20px;
        width: 17.85pt;
  
        position: absolute;
        margin-left: -17.85pt;
      }
  
      .notice .notice-title {
        font-weight: bold;
        margin: 5px 5px 5px 55px;
      }
  
      .Advice>.notice-icon {
        background: no-repeat center url(" data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACQAAAAkCAYAAADhAJiYAAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJbWFnZVJlYWR5ccllPAAAAyJpVFh0WE1MOmNvbS5hZG9iZS54bXAAAAAAADw/eHBhY2tldCBiZWdpbj0i77u/IiBpZD0iVzVNME1wQ2VoaUh6cmVTek5UY3prYzlkIj8+IDx4OnhtcG1ldGEgeG1sbnM6eD0iYWRvYmU6bnM6bWV0YS8iIHg6eG1wdGs9IkFkb2JlIFhNUCBDb3JlIDUuMy1jMDExIDY2LjE0NTY2MSwgMjAxMi8wMi8wNi0xNDo1NjoyNyAgICAgICAgIj4gPHJkZjpSREYgeG1sbnM6cmRmPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5LzAyLzIyLXJkZi1zeW50YXgtbnMjIj4gPHJkZjpEZXNjcmlwdGlvbiByZGY6YWJvdXQ9IiIgeG1sbnM6eG1wPSJodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvIiB4bWxuczp4bXBNTT0iaHR0cDovL25zLmFkb2JlLmNvbS94YXAvMS4wL21tLyIgeG1sbnM6c3RSZWY9Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC9zVHlwZS9SZXNvdXJjZVJlZiMiIHhtcDpDcmVhdG9yVG9vbD0iQWRvYmUgUGhvdG9zaG9wIENTNiAoV2luZG93cykiIHhtcE1NOkluc3RhbmNlSUQ9InhtcC5paWQ6REZDMUEyNEU2NDE5MTFFNEJEQ0RBQTdDNUE3QTlBMzgiIHhtcE1NOkRvY3VtZW50SUQ9InhtcC5kaWQ6REZDMUEyNEY2NDE5MTFFNEJEQ0RBQTdDNUE3QTlBMzgiPiA8eG1wTU06RGVyaXZlZEZyb20gc3RSZWY6aW5zdGFuY2VJRD0ieG1wLmlpZDpERkMxQTI0QzY0MTkxMUU0QkRDREFBN0M1QTdBOUEzOCIgc3RSZWY6ZG9jdW1lbnRJRD0ieG1wLmRpZDpERkMxQTI0RDY0MTkxMUU0QkRDREFBN0M1QTdBOUEzOCIvPiA8L3JkZjpEZXNjcmlwdGlvbj4gPC9yZGY6UkRGPiA8L3g6eG1wbWV0YT4gPD94cGFja2V0IGVuZD0iciI/PnxvIOEAAANBSURBVHjazJhZSFRRGMcdx7KyfcGXpI0iqQeTsigaIiFSK1uMoiIKIwrCgrKpKKLopR5aH1ogX4IiolVKBA2yjQiygooK2mglKA2nRbTp/9H/xO1679xzrhfGP/ycce7cM/97znfO950TisfjKR1JafIntLXO5J4xIAImgQGgBwgD9WRfQQzcAnV81VJ8V+SvIU0tAktBd/AePAfH+PqNhuTaUDAF5IIi0AJOgyPaPeQh+YEKkAkugR3gu8t3G8Bb9owoFZSDNWA5KAN3Ev1YqoeZjeyB+yAbRBOYcdJvsBuMBpfBbXDAbw8dBqtAIagKIF53gkpwEwwGxSaGDtFMP/AlwElUD7pxaMXcTJ0hK+OY9zEwMxJMAH01v98bTAP7vQxlcYwjfAodSYw8YXy8BHma9w0Ha+3ftxs6B/aC65qNRhj4Sj3BNdBL4943DIszbobmcSatN4iJiMNnXcAwzfuPcu2KOhnaBg4aBuldl89fGbSxDpTaDUnPhGjKRNVgH/jJ/z+AfMOZeYIrfb512hczIFs1G+kK+tPIZq7MMnNeWFZpEz0Dc0CtMjQOPDJooACc5fsYc1szg1mS6QJDQ1Vq2NSQZbL7UwzWEaUMTuFRYKDmDLPrhhodZSidOcskdmSYNzlci/kw1MAe/s+QSdJ8x8xfEVBK+cVE7JntvTQkIENxVeApQ81c0JKlzsqLMvSDJUGyJBOhk9VQI7NvsjRejVCqJQXkJtHQDC6O/wzJjBnko6FWlwA11QhwwWqonoFVbtjQZ4fPmgzbKGRlesU+7SVJbtFsZDaX+5MO1yazrCjRbEu2R+ftK7XoOPio2UtTwXRuFp22TStZfHmphIl6u1uRL0nxAbiogsxFUq5OTFAdhLntSaQMVouzLOVLG0MPwR7WyOEEjZ0i7dFT7mgrvbZBUWbvRp+ZW0ePWbIs1N25zmVJ0MRqMijJbHrNRJ5nupUuYnkpT7MhADOlrBLugbF+9/arWesu4f5+hQ8j83nAIKGwjKVqu04/roIcrlFiaDFPOKr5tJ8ssySdtXYOl4Us7oBrXIq5NgrJCZrhgVUBey2bD9TCnlY1TRpfpQKtVSlB98Aq1NGO9P4IMAAkYrdU7bNmeQAAAABJRU5ErkJggg==");
        width: 50px;
        height: 50px;
        float: left;
      }
  
      .Important>.notice-icon {
        background: no-repeat center url(" data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACQAAAAkCAYAAADhAJiYAAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJbWFnZVJlYWR5ccllPAAAAyJpVFh0WE1MOmNvbS5hZG9iZS54bXAAAAAAADw/eHBhY2tldCBiZWdpbj0i77u/IiBpZD0iVzVNME1wQ2VoaUh6cmVTek5UY3prYzlkIj8+IDx4OnhtcG1ldGEgeG1sbnM6eD0iYWRvYmU6bnM6bWV0YS8iIHg6eG1wdGs9IkFkb2JlIFhNUCBDb3JlIDUuMy1jMDExIDY2LjE0NTY2MSwgMjAxMi8wMi8wNi0xNDo1NjoyNyAgICAgICAgIj4gPHJkZjpSREYgeG1sbnM6cmRmPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5LzAyLzIyLXJkZi1zeW50YXgtbnMjIj4gPHJkZjpEZXNjcmlwdGlvbiByZGY6YWJvdXQ9IiIgeG1sbnM6eG1wPSJodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvIiB4bWxuczp4bXBNTT0iaHR0cDovL25zLmFkb2JlLmNvbS94YXAvMS4wL21tLyIgeG1sbnM6c3RSZWY9Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC9zVHlwZS9SZXNvdXJjZVJlZiMiIHhtcDpDcmVhdG9yVG9vbD0iQWRvYmUgUGhvdG9zaG9wIENTNiAoV2luZG93cykiIHhtcE1NOkluc3RhbmNlSUQ9InhtcC5paWQ6REIxQTRGRUM2NDE5MTFFNEE4QzhDQzM1MzAzMjUzQjIiIHhtcE1NOkRvY3VtZW50SUQ9InhtcC5kaWQ6REIxQTRGRUQ2NDE5MTFFNEE4QzhDQzM1MzAzMjUzQjIiPiA8eG1wTU06RGVyaXZlZEZyb20gc3RSZWY6aW5zdGFuY2VJRD0ieG1wLmlpZDpEQjFBNEZFQTY0MTkxMUU0QThDOENDMzUzMDMyNTNCMiIgc3RSZWY6ZG9jdW1lbnRJRD0ieG1wLmRpZDpEQjFBNEZFQjY0MTkxMUU0QThDOENDMzUzMDMyNTNCMiIvPiA8L3JkZjpEZXNjcmlwdGlvbj4gPC9yZGY6UkRGPiA8L3g6eG1wbWV0YT4gPD94cGFja2V0IGVuZD0iciI/PvkMLbIAAAFdSURBVHjaYvz//z/DYAIsIIKRkfEhkPoExH9A3AFwBxOIAAaOHguSQCAQvx0AB4GiiBeIV8BDCAheAzEolH4PUEy9B+I38KCC0rwDmHR4gJgZ2UGDBow6iB4OsgLinUC8H4jdKM9zkILxAhALkaFdBZptkbE5mYl6K8gtlIZQEBaxjIGMMmzl1p+BdNBlLGLHB9JBL7GI3RxIB73DUQ0MaAi9RqsoXw+kg0AJ+CoS/zGskhzIghE5YV+DhtKAOug+EvvSYKg63qFF2aBy0JfB4CBQPfgXT0FJeiOfQgCKpkgg5gLis4PBQY3QSvYfEOsCcclANj88sTQ/Ugay+RGNRSx1IBP1ISxi+wYyykBgE1J0HQZiVkqijBqJ2g+IjaDsc4Mhl1HFIaP9MlIdBEqQ3wbQHV+hBSs8DYkDsQSljSsKAB8QiyE7COSQ2UD8a4AcxAbrUjEOtiE9gAADAHTWZMdTwTXdAAAAAElFTkSuQmCC");
        width: 50px;
        height: 50px;
        float: left;
      }
  
      .Advice.notice-container {
        border-color: #0076c0;
      }
  
      .notice-container {
        margin: 15px 0px 15px 0px;
        border: 1px solid black;
        -moz-border-radius: 4px;
        border-radius: 4px;
        min-height: 50px;
      }
  
      .notice-body {
        margin: 5px 5px 5px 55px;
      }
    </style>
  </head>
  <body>
    <div class="content">
      <h1 class="headline">${toolName}</h1>
      <h2 class="label">Introduction</h2>
      <p>Add your help text here.</p>
    </div>
  </body>
</html>`;
}

function generateLangJson(toolName, toolFuncName) {
  return `{
  "${toolFuncName}": "${toolName}"
}`
}
  
const STATIC_RESOURCES = {
    "Bootstrap.lua": 
`-- %project-entry-path
if _G["NovaMain"] == nil then
  _G["NovaMain"] = require("API.NovaMain")
end

_G["Script"].register("NovaMain.InitApps", function()
  load(_G["NovaMain"].bootstrap(), "bootstrap", "t")()
  _G["_nova_bootstrap_run_app"](_APPNAME, 2)
end)
`
  }